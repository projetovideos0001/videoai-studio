import { useState } from "react";
import {
  Clapperboard, WandSparkles, Download, Clock3, Film, LayoutDashboard,
  Settings2, CircleHelp, Sparkles, ChevronDown, Play, MonitorPlay,
  Smartphone, AlertCircle, CheckCircle2, LoaderCircle, Plus, History
} from "lucide-react";

type Aspect = "vertical" | "horizontal";
type JobStatus = "idle" | "needs-provider";

export default function App() {
  const [prompt, setPrompt] = useState("");
  const [aspect, setAspect] = useState<Aspect>("vertical");
  const [duration, setDuration] = useState("10");
  const [style, setStyle] = useState("cinematic");
  const [status, setStatus] = useState<JobStatus>("idle");
  const [showNotice, setShowNotice] = useState(false);

  function startGeneration() {
    if (!prompt.trim()) {
      setShowNotice(true);
      return;
    }
    setStatus("needs-provider");
    setShowNotice(false);
  }

  const examples = [
    "Um astronauta caminhando em uma floresta bioluminescente",
    "Uma cidade futurista ao pôr do sol, vista aérea cinematográfica",
    "Ondas do mar em câmera lenta numa praia tropical"
  ];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon"><Clapperboard size={21} /></div>
          <div><strong>VideoAI</strong><span>STUDIO</span></div>
        </div>
        <button className="new-project" onClick={() => { setPrompt(""); setStatus("idle"); }}>
          <Plus size={17} /> Novo vídeo
        </button>
        <div className="nav-label">WORKSPACE</div>
        <nav>
          <a className="nav-item active"><WandSparkles size={18} /> Criar vídeo</a>
          <a className="nav-item" onClick={() => setShowNotice(true)}><History size={18} /> Histórico <span className="soon">EM BREVE</span></a>
          <a className="nav-item" onClick={() => setShowNotice(true)}><Film size={18} /> Meus vídeos <span className="soon">EM BREVE</span></a>
        </nav>
        <div className="sidebar-bottom">
          <div className="credits-card">
            <div className="credits-title"><Sparkles size={16} /> Seu espaço criativo</div>
            <p>Prepare suas ideias e transforme prompts em vídeos.</p>
            <div className="credits-meter"><span /></div>
            <small>Geração por IA será conectada na próxima etapa.</small>
          </div>
          <a className="nav-item muted" onClick={() => setShowNotice(true)}><Settings2 size={18} /> Configurações</a>
          <a className="nav-item muted" onClick={() => setShowNotice(true)}><CircleHelp size={18} /> Ajuda</a>
          <div className="profile">
            <div className="avatar">V</div>
            <div className="profile-copy"><strong>VideoAI Studio</strong><span>Plano inicial</span></div>
            <ChevronDown size={16} />
          </div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>Criar vídeo</strong></div>
          <div className="top-actions"><span className="status-pill"><span className="status-dot" /> Projeto inicial</span><button className="icon-button" aria-label="Ajuda" onClick={() => setShowNotice(true)}><CircleHelp size={18} /></button></div>
        </header>

        <div className="page">
          <section className="page-heading">
            <div className="eyebrow"><Sparkles size={14} /> CRIAÇÃO COM INTELIGÊNCIA ARTIFICIAL</div>
            <h1>Transforme ideias em <span>vídeos.</span></h1>
            <p>Descreva a cena que você imagina. Configure o formato e prepare seu próximo vídeo.</p>
          </section>

          <div className="workspace-grid">
            <section className="creation-panel panel">
              <div className="panel-heading">
                <div className="heading-icon"><WandSparkles size={18} /></div>
                <div><h2>Descreva seu vídeo</h2><p>Quanto mais detalhes, melhor o resultado.</p></div>
              </div>

              <label className="field-label" htmlFor="prompt">Prompt <span>DESCRIÇÃO DA CENA</span></label>
              <div className="prompt-wrap">
                <textarea id="prompt" value={prompt} onChange={(e) => { setPrompt(e.target.value); setStatus("idle"); }} placeholder="Ex.: Uma estrada entre montanhas cobertas de névoa ao amanhecer, luz dourada, movimento suave de câmera, estilo cinematográfico..." maxLength={2000} />
                <div className="prompt-footer"><span><WandSparkles size={14} /> Descreva cenário, iluminação, movimento e estilo</span><span>{prompt.length}/2000</span></div>
              </div>

              <div className="examples">
                <span className="field-label">OU EXPERIMENTE UMA IDEIA</span>
                <div className="example-chips">{examples.map((example) => <button key={example} onClick={() => { setPrompt(example); setStatus("idle"); }}>{example}</button>)}</div>
              </div>

              <div className="form-divider" />
              <div className="section-row"><div><h3>Formato do vídeo</h3><p>Escolha a proporção da tela.</p></div><span className="optional">OBRIGATÓRIO</span></div>
              <div className="aspect-options">
                <button className={`aspect-option ${aspect === "vertical" ? "selected" : ""}`} onClick={() => setAspect("vertical")}>
                  <div className="aspect-preview vertical-preview"><Smartphone size={18} /></div><div className="aspect-copy"><strong>Vertical</strong><span>9:16 · Reels, TikTok, Shorts</span></div><span className="radio-dot" />
                </button>
                <button className={`aspect-option ${aspect === "horizontal" ? "selected" : ""}`} onClick={() => setAspect("horizontal")}>
                  <div className="aspect-preview horizontal-preview"><MonitorPlay size={19} /></div><div className="aspect-copy"><strong>Horizontal</strong><span>16:9 · YouTube, apresentações</span></div><span className="radio-dot" />
                </button>
              </div>

              <div className="controls-row">
                <div className="control-group"><label className="field-label" htmlFor="duration"><Clock3 size={14} /> Duração</label><div className="select-wrap"><select id="duration" value={duration} onChange={(e) => setDuration(e.target.value)}><option value="5">5 segundos</option><option value="10">10 segundos</option><option value="15">15 segundos</option><option value="30">30 segundos</option><option value="60">60 segundos</option><option value="custom">Definida pelo provedor</option></select><ChevronDown size={15} /></div></div>
                <div className="control-group"><label className="field-label" htmlFor="style"><Sparkles size={14} /> Estilo visual</label><div className="select-wrap"><select id="style" value={style} onChange={(e) => setStyle(e.target.value)}><option value="cinematic">Cinematográfico</option><option value="realistic">Realista</option><option value="animation">Animação</option><option value="anime">Anime</option><option value="documentary">Documental</option></select><ChevronDown size={15} /></div></div>
              </div>

              {showNotice && <div className="inline-notice"><AlertCircle size={16} /> {prompt.trim() ? "Este recurso ficará disponível após conectar o provedor de vídeo." : "Escreva uma descrição para continuar."}</div>}
              {status === "needs-provider" && <div className="provider-notice"><CheckCircle2 size={17} /><div><strong>Prompt preparado!</strong><span>O formulário está pronto. Para gerar o arquivo real, ainda precisamos configurar a API de vídeo e o backend seguro.</span></div></div>}

              <button className="generate-button" onClick={startGeneration}><WandSparkles size={18} /> Preparar geração <span>→</span></button>
              <p className="generation-footnote"><AlertCircle size={13} /> A geração real ainda não está ativa. Nenhuma cobrança será feita por este botão nesta versão.</p>
            </section>

            <aside className="preview-column">
              <section className="preview-panel panel">
                <div className="preview-header"><div><h2>Pré-visualização</h2><p>Seu vídeo aparecerá aqui</p></div><span className="preview-tag"><span /> AGUARDANDO</span></div>
                <div className={`preview-canvas ${aspect === "horizontal" ? "wide" : ""}`}>
                  <div className="preview-glow glow-one" /><div className="preview-glow glow-two" />
                  <div className="preview-art">
                    <div className="art-orbit orbit-one" /><div className="art-orbit orbit-two" />
                    <div className="art-core"><Clapperboard size={31} strokeWidth={1.2} /></div>
                    <div className="art-star star-one">✦</div><div className="art-star star-two">✧</div><div className="art-star star-three">·</div>
                  </div>
                  <div className="canvas-caption"><span className="live-dot" /> PRONTO PARA CRIAR</div>
                  <div className="canvas-center"><div className="play-button"><Play size={20} fill="currentColor" /></div><span>Seu próximo vídeo começa com uma ideia.</span></div>
                </div>
                <div className="preview-meta"><div><span>FORMATO</span><strong>{aspect === "vertical" ? "Vertical · 9:16" : "Horizontal · 16:9"}</strong></div><div><span>DURAÇÃO</span><strong>{duration === "custom" ? "Variável" : `${duration} segundos`}</strong></div></div>
                <button className="download-button" disabled><Download size={17} /> Baixar vídeo <span>Disponível após gerar</span></button>
              </section>
              <section className="tip-card"><div className="tip-icon"><Sparkles size={17} /></div><div><strong>Dica para melhores resultados</strong><p>Inclua o assunto, o ambiente, a iluminação, o movimento de câmera e o estilo visual no seu prompt.</p></div></section>
            </aside>
          </div>
          <footer className="page-footer"><span>VideoAI Studio <span className="footer-dot">·</span> Versão inicial 0.1</span><span>Feito para transformar ideias em movimento.</span></footer>
        </div>
      </main>
    </div>
  );
}