# VideoAI Studio

Interface inicial para uma aplicação web de geração de vídeos por IA a partir de prompts.

## Estado atual

Esta versão contém a interface inicial e os controles de prompt, formato, duração e estilo. **A geração real ainda não está conectada**; o botão não chama APIs pagas e não cria um arquivo de vídeo. A integração com um provedor de vídeo deve ser implementada no backend antes de habilitar a geração e o download.

## Stack inicial

- React + TypeScript + Vite
- Lucide React para ícones
- CSS responsivo sem framework de UI obrigatório

## Executar localmente

Requer Node.js 20 ou compatível com Vite 6.

```bash
npm install
npm run dev
```

Para validar a build:

```bash
npm run build
```

## Próximas etapas

1. Importar este projeto para um repositório GitHub.
2. Conectar o repositório ao Lovable.
3. Escolher um provedor de vídeo com API, verificando duração, proporções suportadas, preço, termos de uso e disponibilidade regional.
4. Implementar uma função de backend para validar prompts, iniciar geração e consultar o status.
5. Guardar chaves de API como secrets no backend, nunca no código frontend nem em variáveis `VITE_*`.
6. Armazenar os vídeos gerados em armazenamento de objetos e fornecer links de download seguros com expiração.
7. Exibir custos estimados/limites antes de iniciar tarefas pagas e tratar falhas, limites de taxa e tarefas demoradas.

## Arquitetura recomendada

- **Frontend:** esta aplicação React.
- **Backend:** função serverless (por exemplo, Supabase Edge Functions ou serviço equivalente).
- **Banco de dados opcional:** tarefas, status, prompt, duração, proporção e URL de resultado.
- **Provedor de vídeo:** camada adaptadora no backend para que seja possível trocar de fornecedor sem refazer a interface.
- **Armazenamento:** bucket privado com links temporários para downloads.

## Segurança e custos

- Não inclua tokens ou chaves de API no frontend, no GitHub ou em commits.
- Não inicie geração real sem confirmar provedor, preço e limites.
- Respeite os direitos autorais e os termos de uso de mídias e serviços integrados.
- A duração e os formatos reais dependerão do provedor escolhido.

## Lovable

Depois de criar o repositório no GitHub, importe/conecte-o na integração GitHub do Lovable. A disponibilidade exata das opções depende da conta e da interface atual do Lovable.
